import tkinter as tk

class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)  # Call tk.Frame.__init__(master)

if __name__ == '__main__':
    master = tk.Tk()
    app = Application(master=master)
    app.mainloop()
