import tkinter as tk

import tkinter.messagebox

class Application(tk.Frame):
    def __init__(self, window_width, window_height, master=None):
        super().__init__(master)  # Call tk.Frame.__init__(master)
        self.master = master

        # Create a frame and place it in the window
        frame = tk.Frame(self.master, width=window_width, height=window_height)
        frame.pack()

        # Create a canvas and place it in the frame
        self.canvas = tk.Canvas(frame, bg='red')
        self.canvas.place(x=100, y=20, width=500, height=240)

        # Create a rectangle in the canvas, (100, 0) is the top left corner, (400, 200) is the bottom right corner
        self.rectangle = self.canvas.create_rectangle(100, 0, 400, 200, fill='blue')

        # Create a button to change the color of the rectangle, and place it in the frame
        button = tk.Button(frame, text="Change Color", command=self.change_color)
        button.place(x=300, y=40)

        self.text = tk.Text(frame, bg='white', borderwidth=2, font=('Arial', 8))
        self.text.place(x=100, y=270, width=500, height=20)

        self.label = tk.Label(frame, bg='gray', borderwidth=2, font=('Arial', 8))
        self.label.place(x=30, y=270, width=50, height=20)
        self.label.config(text='Blue')


    def change_color(self):
        self.canvas.itemconfig(self.rectangle, fill='yellow')
        tk.messagebox.showinfo(title="Message box", message="Change colour")
        self.text.insert(tk.END, "Welcome to CSE2UI")  # show the information to the text widget
        self.label.config(text='Yellow')


if __name__ == '__main__':
     master = tk.Tk()
     window_width = 700
     window_height = 300
     # Define window size
     master.geometry(str(window_width) + 'x' + str(window_height))
     master.resizable(0, 0)  # can not change the size of the window
     app = Application(window_width, window_height, master=master)
     app.mainloop()
